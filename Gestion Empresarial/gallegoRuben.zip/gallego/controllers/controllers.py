# -*- coding: utf-8 -*-
# from odoo import http


# class Gallego(http.Controller):
#     @http.route('/gallego/gallego/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gallego/gallego/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('gallego.listing', {
#             'root': '/gallego/gallego',
#             'objects': http.request.env['gallego.gallego'].search([]),
#         })

#     @http.route('/gallego/gallego/objects/<model("gallego.gallego"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gallego.object', {
#             'object': obj
#         })
