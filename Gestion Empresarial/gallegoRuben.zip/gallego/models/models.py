# -*- coding: utf-8 -*-
import datetime

from odoo import models, fields, api


class aeropuerto(models.Model):
    _name = "gallego.aeropuerto"
    _description = "gallego.aeropuerto"

    name = fields.Char(string="Nombre del Aeropuerto", required=True)
    capacity = fields.Integer(string="Número máximo de pasageros")
    location = fields.Char(string="Localización del aeropuerto", required=True)
    color = fields.Char(string="Color del Aeropuerto")
    employees = fields.Integer(string="Numero de empleados")

    _sql_constraints = [('name', 'unique(name)', 'No se pueden repetir los nombres')]

    id_terminal = fields.One2many('gallego.terminal', 'id_aeropuerto', string='Terminales')


class terminal(models.Model):
    _name = "gallego.terminal"
    _description = "gallego_terminal"

    name = fields.Char(string="Nombre Terminal", required=True)
    capacity = fields.Integer(string="Número maximo de pasageros", required=True)
    location = fields.Char(string="Localocacion de la Terminal", required=True)
    color = fields.Char(string="Color de la Terminal")
    employee = fields.Char(string="Nombre del Empleado a cargo")

    id_aeropuerto = fields.Many2one('gallego.aeropuerto', string='Id del Aropuerto', required=True)
    id_puerta = fields.One2many('gallego.puerta', 'terminal_id', string='Puertas')


class puerta(models.Model):
    _name = "gallego.puerta"
    _description = "gallego.puerta"

    name = fields.Char(string="Nombre", required=True)
    numero = fields.Integer(string="Numero de Puerta", required=True)
    color = fields.Char(stirng="Color puerta")
    zona = fields.Char(string="Zona de la Puerta")
    direccion = fields.Char(string="Direccion pasageros")

    terminal_id = fields.Many2one('gallego.terminal', string='Id de la Terminal', required=True)
    id_avionPuerta = fields.One2many('gallego.avion_puerta', 'puerta_id', string="Puerta-Avion")


class avion_puerta(models.Model):
    _name = "gallego.avion_puerta"
    _description = "gallego.avion_puerta"

    name = fields.Char(string="Nombre de puerta avion", required=True)
    numero = fields.Integer(string="numero de puerta")
    direccion = fields.Selection([('entrada', 'Entrada'), ('salida', 'Salida')], required=True)
    fecha = fields.Date(string='Fecha', default=datetime.date.today().strftime('%Y-%m-%d'))

    puerta_id = fields.Many2one('gallego.puerta', string='Id de la Puerta', required=True)
    avion_id = fields.Many2one('gallego.avion', string='Id del Avion', required=True)


class avion(models.Model):
    _name = "gallego.avion"
    _description = "gallego.avion"

    name = fields.Char(string="Nombre del avion", required=True)
    matricula = fields.Char(string="Matricula", required=True)
    empresa = fields.Char(string="Nombre de empresa pertenece")
    combustible = fields.Integer(string="Litros de combustible")
    debe_repostar = fields.Boolean(string="Debe repostar", compute="repostarCheck")

    id_avion = fields.One2many('gallego.avion_puerta', 'avion_id', string="Puerta-Avion")

    @api.onchange('combustible')
    def repostarCheck(self):
        for record in self:
            if (record.combustible < 300):
                record.debe_repostar = True
            else:
                record.debe_repostar = False
